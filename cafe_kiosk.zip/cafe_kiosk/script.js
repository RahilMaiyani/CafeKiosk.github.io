document.querySelector(".start-order").addEventListener("click", () => {
    // Hide the welcome screen and show the main content
    document.querySelector(".welcome-screen").classList.add("d-none");
    document.querySelector(".main-content").classList.remove("d-none");
});

// Menu Data
const menuData = {
    HotCoffee: [
        { name: "Americano", price: 5.99, img: "/Images/HotCoffee/Americano.jpg" },
        { name: "Dark Roast", price: 4.99, img: "/Images/HotCoffee/PremiumCoffee.jpg" },
        { name: "Cappuccino", price: 6.99, img: "/Images/HotCoffee/Cappuccino.jpg" },
        { name: "Caramel Cappuccino", price: 5.99, img: "/Images/HotCoffee/CaramelCappuccino.jpg" },
        { name: "Vanilla Cappuccino", price: 4.99, img: "/Images/HotCoffee/VanillaCappuccino.jpg" },
        { name: "French Vanilla Latte", price: 6.99, img: "/Images/HotCoffee/FrenchVanilla.jpg" },
        { name: "Classic Roast Latte", price: 5.99, img: "/Images/HotCoffee/Latte.jpg" },
        { name: "Caramel Macchiato", price: 4.99, img: "/Images/HotCoffee/CaramelMacchiato.jpg" },
        { name: "Classic Mocha Latte", price: 6.99, img: "/Images/HotCoffee/Mocha.jpg" },
    ],
    ColdCoffee: [
        { name: "Classic Iced Coffee", price: 7.99, img: "/Images/ColdCoffee/IcedCoffee.jpg" },
        { name: "Iced Caramel Coffee", price: 8.99, img: "/Images/ColdCoffee/IcedCaramelCoffee.jpg" },
        { name: "Caramel Frappe", price: 10.99, img: "/Images/ColdCoffee/CaramelFrappe.jpg" },
        { name: "Iced Macchiato", price: 9.99, img: "/Images/ColdCoffee/IcedCaramelMacchiato.jpg" },
        { name: "Classic Iced Mocha", price: 9.99, img: "/Images/ColdCoffee/IcedMocha.jpg" },
        { name: "Iced Mocha Frappe", price: 10.99, img: "/Images/ColdCoffee/MochaFrappe.jpg" },
    ],
    Desserts: [
        { name: "Classic Vanilla Shake", price: 9.99, img: "/Images/Desserts/VanillaShake.jpg" },
        { name: "Chocolate Shake", price: 9.99, img: "/Images/Desserts/ChocolateShake.jpg" },
        { name: "Hot Fudge Sundae", price: 6.99, img: "/Images/Desserts/HotFudgeSundae.jpg" },
        { name: "SoftServe Cone", price: 3.99, img: "/Images/Desserts/VanillaCone.jpg" },
        { name: "M&M SoftServe", price: 9.99, img: "/Images/Desserts/MandMSoftServe.jpg" },
        { name: "OREO SoftServe", price: 9.99, img: "/Images/Desserts/OREOSoftServe.jpg" },
        { name: "ChocolateChip Cookie", price: 3.99, img: "/Images/Desserts/ChocolateChipCookie.jpg" },
        { name: "Baked ApplePie", price: 3.99, img: "/Images/Desserts/BakedApplePie.jpg" },
    ],
};


let cart = [];

// Category button event listener
document.querySelectorAll(".category-btn").forEach(button => {
    button.addEventListener("click", (e) => {
        const category = e.target.dataset.category;
        const menuItems = menuData[category];

        const menuSection = document.querySelector(".menu-items");
        menuSection.innerHTML = "";

        menuItems.forEach(item => {
            const itemDiv = document.createElement("div");
            itemDiv.classList.add("col-md-4", "item");
            itemDiv.innerHTML = `
                <div class="card" id="showed-item">
                    <img src="${item.img}" alt="${item.name}" class="card-img-top">
                    <div class="card-body">
                        <h5 class="card-title">${item.name}</h5>
                        <p class="card-text">$${item.price}</p>
                        <button class="add-to-cart" data-name="${item.name}" data-price="${item.price}" data-img="${item.img}">Add to Cart</button>
                    </div>
                </div>
            `;
            menuSection.appendChild(itemDiv);
        });
    });
});

// Add to Cart functionality
document.querySelector(".menu-section").addEventListener("click", (e) => {
    if (e.target.classList.contains("add-to-cart")) {
        const name = e.target.dataset.name;
        const price = parseFloat(e.target.dataset.price);
        const img = e.target.dataset.img;

        const itemIndex = cart.findIndex(item => item.name === name);
        if (itemIndex === -1) {
            cart.push({ name, price, img, quantity: 1 });
        } else {
            cart[itemIndex].quantity++;
        }

        updateCart();
    }
});

// Update Cart display (same as your existing code)
function updateCart() {
    const cartItemCount = document.getElementById("cart-item-count");
    const cartTotal = document.getElementById("cart-total");

    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

    cartItemCount.textContent = itemCount;
    cartTotal.textContent = total.toFixed(2);
}

// View Cart Modal functionality (same as your existing code)
document.querySelector(".view-cart").addEventListener("click", () => {
    closeModals(); // Close all open modals
    const viewCartModal = new bootstrap.Modal(document.getElementById('viewCartModal'));
    viewCartModal.show();
    loadCartItems();
});

// Load Cart Items in Modal
function loadCartItems() {
    const cartItemsList = document.getElementById("cart-items-list");
    const cartTotalModal = document.getElementById("cart-total-modal");
    cartItemsList.innerHTML = "";
    cart.forEach((item, index) => {
        const itemDiv = document.createElement("div");
        itemDiv.classList.add("cart-item","d-flex", "justify-content-between", "align-items-center", "mb-2");
        itemDiv.innerHTML = `
            <div class="d-flex">
                <img src="${item.img}" class="img-fluid" alt="${item.name}" style="width: 50px; height: 50px; object-fit: cover;">
                <span class="ms-3">${item.name} (x${item.quantity})</span>
            </div>
            <div class="d-flex">
                <span>$${(item.price * item.quantity).toFixed(2)}</span>
                <button class="remove-item ms-2" data-index="${index}">Remove</button>
            </div>
        `;
        cartItemsList.appendChild(itemDiv);
    });

    let total = 0;
    cart.forEach(item => {
        total += item.price * item.quantity;
    });
    cartTotalModal.innerText = total.toFixed(2);
}

// Remove Item from Cart
document.querySelector("#cart-items-list").addEventListener("click", (e) => {
    if (e.target.classList.contains("remove-item")) {
        const itemIndex = e.target.getAttribute("data-index");
        cart.splice(itemIndex, 1);
        updateCart();
        loadCartItems();
    }
});

// Checkout Button (same as your existing code)
document.querySelector("#checkout-btn").addEventListener("click", () => {
    closeModals(); // Close all open modals
    const orderModal = new bootstrap.Modal(document.getElementById('orderModal'));
    orderModal.show();
});

// Dine-In or Takeout Selection
document.querySelector(".dine-in").addEventListener("click", () => {
    showPaymentMethodModal();
});
document.querySelector(".take-away").addEventListener("click", () => {
    showPaymentMethodModal();
});

// Show Payment Method Modal
function showPaymentMethodModal() {
    closeModals(); // Close all open modals
    const paymentMethodModal = new bootstrap.Modal(document.getElementById('paymentMethodModal'));
    paymentMethodModal.show();
}

// Handle Payment Method Selection
document.querySelector(".pay-card").addEventListener("click", () => {
    handleCheckout("card");
});
document.querySelector(".pay-counter").addEventListener("click", () => {
    handleCheckout("counter");
});

// Handle Checkout
function handleCheckout(paymentMethod) {
    closeModals(); // Close all open modals
    const paymentModal = new bootstrap.Modal(document.getElementById('paymentModal'));
    paymentModal.show();

    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    document.getElementById("final-total").textContent = total.toFixed(2);

    // Optionally handle different payment methods here (e.g., show message or redirect based on `paymentMethod`)
}

// Payment Success
document.querySelector("#pay-now").addEventListener("click", () => {
    closeModals(); // Close all open modals
    const orderNumber = Math.floor(Math.random() * 10000); // Random Order Number

    const orderConfirmationModal = new bootstrap.Modal(document.getElementById('orderConfirmationModal'));
    orderConfirmationModal.show();
    document.getElementById("order-number").textContent = orderNumber;
});

// Start New Order
document.querySelector("#start-over-btn").addEventListener("click", () => {
    location.reload(); // Reload the page to start a new order
});

// Function to close all open modals (same as your existing code)
function closeModals() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        const bootstrapModal = bootstrap.Modal.getInstance(modal);
        if (bootstrapModal) {
            bootstrapModal.hide();
        }
    });
}
